<?php $__env->startSection('content'); ?>
    <div class="row row-cols-1 row-cols-md-3 mb-3 text-center">
        <div class="col-12">
            <table class="table dataTable">
                <thead>
                    <th>City</th>
                    <th>Action</th>
                </thead>
                <tbody>
                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('city.home', ['city' => $city->slug])); ?>" <?php if(isset($currentCity->id) && $city->id == $currentCity->id): ?> style="font-weight: bold;" <?php endif; ?>>
                                <?php echo e($city->name); ?>

                            </a>
                        </td>
                        <td>
                            <a href="<?php echo e(url($city->slug)); ?>">
                                <button class="btn btn-sm btn-secondary">Open</button>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/multiRegions/resources/views/home.blade.php ENDPATH**/ ?>