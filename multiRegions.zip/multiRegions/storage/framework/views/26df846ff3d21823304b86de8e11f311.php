<html lang="en">
<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<div class="container py-3">
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main>
        <?php $__env->startSection('content'); ?>
            <?php echo $__env->yieldSection(); ?>
    </main>
</div>
<script src="<?php echo e(asset('assets/js/jquery-3.7.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/datatables.min.js')); ?>"></script>
<script>
    new DataTable('.datatable');
</script>
</body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/multiRegions/resources/views/layout/theme.blade.php ENDPATH**/ ?>